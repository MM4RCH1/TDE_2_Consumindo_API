import { Text, View, StyleSheet } from "react-native";
import { Page } from "../pages/login";

//importar os modais e pages aqui.

export default function Index() {
  return (
      <Page/>
  );
}
